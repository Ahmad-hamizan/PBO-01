package Praktikum07.interfaces;

public interface Assets {
    public double nilaiAsset();
}
