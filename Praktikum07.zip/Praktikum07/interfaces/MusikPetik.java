package Praktikum07.interfaces;

public interface MusikPetik {
    public void petik();
}
