package Praktikum07.interfaces;

public interface MusikTekan {
    public void tekan();
}
