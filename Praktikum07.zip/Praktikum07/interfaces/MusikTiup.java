package Praktikum07.interfaces;

public interface MusikTiup {
    public void tiup();
}
