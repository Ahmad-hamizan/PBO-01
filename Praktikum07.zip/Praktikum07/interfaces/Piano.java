package Praktikum07.interfaces;

public class Piano implements MusikTekan {
    @Override
    public void tekan() {
        System.out.println("Suara piano tinuninuninunideng...tengtengdungdung");
    }
}