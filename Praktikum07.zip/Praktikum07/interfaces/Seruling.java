package Praktikum07.interfaces;

public class Seruling implements MusikTiup{
    @Override
    public void tiup() {
        System.out.println("Suara Seruling tulalit...tulalit");
    }
}
