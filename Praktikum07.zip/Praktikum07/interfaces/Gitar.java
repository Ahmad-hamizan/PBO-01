package Praktikum07.interfaces;

public class Gitar implements MusikPetik {
    @Override
    public void petik() {
        System.out.println("Suara gitar jreng...jreng...jreeeettt");
    }
}
