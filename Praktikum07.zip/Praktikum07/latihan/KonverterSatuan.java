package Praktikum07.latihan;

public interface KonverterSatuan {
    public float konversi(float input);

    public String satuanInput();

    public String satuanOutput();

}
